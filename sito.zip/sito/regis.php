
<?php
	//$bdd= new PDO('mysql:host=127.0.0.1;dbname=dbase1', 'root', '');
	 include "database.php";

	if(isset($_POST['submit']))
		{
	   $firstname = htmlspecialchars($_POST['firstname']); 
	   $lastname = htmlspecialchars($_POST['lastname']);
	   $email = htmlspecialchars($_POST['email']);
	   $pass = sha1($_POST['pass']);
	   $confirm = sha1($_POST['confirm']);

	   if(!empty($_POST['firstname']) AND !empty($_POST['lastname']) AND !empty($_POST['email']) AND !empty($_POST['pass']) AND !empty($_POST['confirm']))
		   {
	            if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
	               $reqemail =$bdd->prepare("SELECT * FROM users WHERE email = ?");
	               $reqemail->execute(array($email));
	               $emailexist = $reqemail->rowCount();
	               if($emailexist == 0) {
	                  if($pass ==$confirm) {
	                     $insertusr = $bdd->prepare("INSERT INTO users(firstname,lastname, email, pass) VALUES(?, ?, ?, ?)");
	                     $insertusr->execute(array($firstname, $lastname, $email, $pass));
	                     $error = "il tuo account è stato creato ! <a href=\"connexion.php\">login</a>";
	                  } else {
	                     $error = "le password non corrispondono!";
	                  }
	               } else {
	                 $error = "indirizzo mail già usato !";
	               }
	            } else {
	               $error = "email non valida !";
	            }
	      
	   } else {
	      $error ="compilare tutti i campi!";
	   }
	}
?>

<html>     
 

  <body>
   
   <br><br></br></br>
   
    <section>

    <h2>Registration</h2>

	 <form action="registration.php" method="POST" class="form"id="form"> 
	 
<?php
  if(isset($error)) {
	 echo '<font color="red">'.$error."</font>";
  }

?>

   <div class="form-control">
  <input type="text" id="firstname" name="firstname" placeholder ="Firstname">
    <i class="fas fa-check-circle"></i>
	 <i class="fas fa-exclamation-circle"></i>
      <small>Error message</small>
   </div>         
  
    <div class="form-control">
   <input type="text" id="lastname" name="lastname" placeholder="Lastname">
    <i class="fas fa-check-circle"></i>
    <i class="fas fa-exclamation-circle"></i>
      <small>Error message</small>
   </div>
   
    <div class="form-control">
   <input type="email" id= "email" name ="email" placeholder="E-mail">
   <i class="fas fa-check-circle"></i>
    <i class="fas fa-exclamation-circle"></i>
      <small>Error message</small>
   </div>
   
   
   <div class="form-control">
   <input type="password" id="pass" name="pass" placeholder ="Password">
    <i class="fas fa-check-circle"></i>
    <i class="fas fa-exclamation-circle"></i>
      <small>Error message</small>
   </div>
   
    
   <div class="form-control">
   <input type="password" id ="confirm" name="confirm" placeholder="Confirm password">
    <i class="fas fa-check-circle"></i>
    <i class="fas fa-exclamation-circle"></i>
      <small>Error message</small>
   </div>
     
    <input type="submit" name="submit" value="submit">
    <p class="message"><b>hai già un account ?</b><a href='file:///C:/xampp/htdocs/login.html' class="access"> Accedi </a></p>
	</form>
	
	</section>
		<!---i had linked my javascript file----->
	


   </body>
   
   <br><br><br>
    <footer>
		 <p>
		 Copyright &copy 2021 by Danny k. for AcquAction Data. All Rights Reserved.
		 </p>
    </footer>
   
 </html>
