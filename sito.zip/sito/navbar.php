<!DOCTYPE html>
<html lang = "it">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel = "stylesheet" href = "css/nav.css">

</head>
<body>

<ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="aboutUs.php">Chi Siamo</a></li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Malattie</a>
    <div class="dropdown-content">
      <a href="#">Diabete</a>
      <a href="#">Cancro</a>
      <a href="#">Fumo</a>
    </div>
  </li>
  <li><a href="login.php"> Accedi </a></li>
  <li><a href="registration.php">Registrati </a></li>
</ul>

</body>
</html>
